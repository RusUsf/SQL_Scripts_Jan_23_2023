
--Backing up OnMedDBNew Database
backup database OnMedDBNew to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\Backup\OnMedDBNew_FULL_Nov_1_5_25PM.bak' with init, checksum, compression

--Restoring SecureRT from OnMedDBNew backup file
restore database SecureRT from disk = 'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\Backup\OnMedDBNew_FULL_Nov_1_5_25PM.bak' with replace,
move 'OnMedDBNew' to 'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\SecureRT.mdf',
move 'OnMedDBNew_log' to 'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\SecureRT_log.ldf'


