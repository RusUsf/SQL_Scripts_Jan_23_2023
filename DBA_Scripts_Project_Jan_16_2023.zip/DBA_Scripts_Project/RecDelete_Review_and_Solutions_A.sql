
--Testing and Implimenting ON UPDATE/DELETE CASCADE options for FK constraints 
--Benefits of these options minimazing Data Anomalies when updating/deleting records;
--ability to update/delete records comprehansively

--Problem: cannot delete records from Users table because Employees and UserRoles tables have 
--FK referencing UserId in Users table
delete from Users where RecDelete =1        --will throw an error (one solution is to use three separate DELETE statements)

--Step 1: Drop existing FK constraints

ALTER TABLE [dbo].[Employees] DROP CONSTRAINT [fk_Employees_Users]

ALTER TABLE [dbo].[UserRoles] DROP CONSTRAINT [fk_UserRoles_Users]

--Step 2: Creaate new FK constraints with ON UPDATE/DELETE options 
ALTER TABLE [dbo].[Employees] WITH CHECK ADD CONSTRAINT [fk_Employees_Users] FOREIGN KEY([UserId]) 
REFERENCES [dbo].[Users] ([UserId]) ON UPDATE CASCADE ON DELETE CASCADE 

ALTER TABLE [dbo].[UserRoles] WITH CHECK ADD CONSTRAINT [fk_UserRoles_Users] FOREIGN KEY([UserId]) 
REFERENCES [dbo].[Users] ([UserId]) ON UPDATE CASCADE ON DELETE CASCADE 

--Step 3:
--Delete Records from Users table which marked for Deletion and automatically 
--delete records associcated with the UserIds in Employees and UserRoles tables!!!
delete from Users where RecDelete =1
