--Backup OnMedDBNew database first!!!

--Use Ola Hallengren's  BackupDatabase stored procedure with compress, checksum and encrypt options
use AdminDB
EXECUTE [dbo].[DatabaseBackup]
@Databases = 'USER_DATABASES',
@Directory = N'D:\BACKUP_SHARE',
@BackupType = 'FULL',
@Verify = 'Y',
@CleanupTime = 168,
@CheckSum = 'Y',
@LogToTable = 'Y',
@Compress ='Y',
@Encrypt = 'Y',
@EncryptionAlgorithm ='AES_256',
@ServerCertificate = 'BackupEncryptionCert'
use master


--Select UserId, Email, RecDelete from Users table where Record Delete column is 1
use OnMedDBNew
select UserId, email, RecDelete from Users where RecDelete = 1

--Counts of all UserIds 
select 'Users' as TableName, count(UserId) as 'Counts of UserId' from Users 
union
select 'Employees', count(UserId) from Employees
union
select 'UserRoles', count(UserId) from UserRoles
order by 2 desc
--Counts of UserIds with Record Delete value 1
select 'Users' as TableName, count(UserId) as 'Counts of UserId RecDelete 1' from Users where RecDelete = 1
union
select 'Employees', count(UserId) from Employees where RecDelete = 1 
union
select 'UserRoles', count(UserId) from UserRoles where UserId in (select UserId from Users where RecDelete = 1)
order by 2 desc

--Select UserId records from Employees and UserRoles tables where Record Delete value is 1 in Users tables
use OnMedDBNew
select e.UserId 
from Employees e 
join Users u on e.UserId = u.UserId
where e.UserId in (select UserId from Users where RecDelete = 1) 

--Why UserRoles table has 3 UserId records marked Record Delete as 1 and Users table has 12?
use OnMedDBNew
select r.UserId 
from Employees e 
join Users u on e.UserId = u.UserId
join UserRoles r on r.UserId = u.UserId
where r.UserId in (select UserId from Users where RecDelete = 1)   


--Testing and Implimenting ON UPDATE/DELETE CASCADE options for FK constraints 
--Benefits of these options minimazing Data Anomalies when updating/deleting records;
--ability to update/delete records comprehansively

--Problem: cannot delete records from Users table because Employees and UserRoles tables have 
--FK referencing UserId in Users table
delete from Users where RecDelete =1        --will throw an error (one solution is to use three separate DELETE statements)

--Step 1: Drop existing FK constraints

ALTER TABLE [dbo].[Employees] DROP CONSTRAINT [fk_Employees_Users]

ALTER TABLE [dbo].[UserRoles] DROP CONSTRAINT [fk_UserRoles_Users]

--Step 2: Creaate new FK constraints with ON UPDATE/DELETE options 
ALTER TABLE [dbo].[Employees] WITH CHECK ADD CONSTRAINT [fk_Employees_Users] FOREIGN KEY([UserId]) 
REFERENCES [dbo].[Users] ([UserId]) ON UPDATE CASCADE ON DELETE CASCADE 

ALTER TABLE [dbo].[UserRoles] WITH CHECK ADD CONSTRAINT [fk_UserRoles_Users] FOREIGN KEY([UserId]) 
REFERENCES [dbo].[Users] ([UserId]) ON UPDATE CASCADE ON DELETE CASCADE 

--Step 3:
--Delete Records from Users table which marked for Deletion and automatically 
--delete records associcated with the UserIds in Employees and UserRoles tables!!!
delete from Users where RecDelete =1

--Check records which marked with Record Delete value 1 and see if they were deleted from all three tables
--Records were deleted from Users and Employees tables
use OnMedDBNew
select e.UserId 
from Employees e 
join Users u on e.UserId = u.UserId
where e.UserId in (select UserId from Users where RecDelete = 1) 

--Records were deleted from UserRoles table
use OnMedDBNew
select e.UserId 
from Employees e 
join Users u on e.UserId = u.UserId
join UserRoles r on r.UserId = u.UserId
where e.UserId in (select UserId from Users where RecDelete = 1)   



--Step 4: Restore OnMedDbNew Database with original FK constraint options and go to step 1 to repeat the demo

--Use Tim Radney's Restore Script which uses MSDB Backup Hisotry records to generate Restore Script

use master
--Clear backup history just in case I have ran this demo before.
--USE MSDB;
--GO
--DECLARE @DATE DATETIME
--SET @DATE = GETDATE()+90
--EXEC SP_DELETE_BACKUPHISTORY @DATE;
--GO


/* Now lets run a simple script to generate a restore script
that includes the last FULL backup and each transaction log
since the last FULL backup, this can be a life saver */
--BEGIN SCRIPT

DECLARE @databaseName sysname
DECLARE @backupStartDate datetime
DECLARE @backup_set_id_start INT
DECLARE @backup_set_id_end INT

-- set database to be used
SET @databaseName = 'OnMedDbNew';                  -- *** set database to be used ***


SELECT @backup_set_id_start = MAX(backup_set_id) 
	FROM  msdb.dbo.backupset 
	WHERE database_name = @databaseName AND TYPE = 'D';


SELECT @backup_set_id_end = MIN(backup_set_id) 
	FROM  msdb.dbo.backupset 
	WHERE database_name = @databaseName AND TYPE = 'D'
	AND backup_set_id > @backup_set_id_start;

IF @backup_set_id_end IS NULL SET @backup_set_id_end = 999999999;

SELECT backup_set_id, 'RESTORE DATABASE ' + @databaseName + ' FROM DISK = ''' 
               + mf.physical_device_name + ''' WITH NORECOVERY, replace'
	FROM msdb.dbo.backupset b,
         msdb.dbo.backupmediafamily mf
	WHERE b.media_set_id = mf.media_set_id
          AND b.database_name = @databaseName
          AND b.backup_set_id = @backup_set_id_start
UNION
SELECT backup_set_id, 'RESTORE LOG ' + @databaseName + ' FROM DISK = ''' 
          + mf.physical_device_name + ''' WITH NORECOVERY'
	FROM  msdb.dbo.backupset b,
          msdb.dbo.backupmediafamily mf
	WHERE b.media_set_id = mf.media_set_id
          AND b.database_name = @databaseName
          AND b.backup_set_id >= @backup_set_id_start AND b.backup_set_id < @backup_set_id_end
          AND b.type = 'L'
UNION
SELECT 999999999 AS backup_set_id, 'RESTORE DATABASE ' + @databaseName + ' WITH RECOVERY'
ORDER BY backup_set_id;
GO

--Restore Script, generated by Tim Radney's script:
use master
RESTORE DATABASE OnMedDbNew FROM DISK = 'D:\BACKUP_SHARE\ONMED_RUS$SQL2017\OnMedDBNew\FULL\ONMED_RUS$SQL2017_OnMedDBNew_FULL_20221103_145053.bak' WITH NORECOVERY, replace
RESTORE DATABASE OnMedDbNew WITH RECOVERY
--Go to line 1

