
--Replace 'Employees' with table name you are interested in
declare @TableName nvarchar(250)
set @TableName = 'Employees'

--Finds REQUIRED (non nullable) collumns in SQL Server Database
select schema_name(tab.schema_id) as schema_name,
    tab.name as table_name, 
    col.column_id,
    col.name as column_name,
    t.name as data_type,
    col.max_length,
    col.precision
from sys.tables as tab
    inner join sys.columns as col
        on tab.object_id = col.object_id
    left join sys.types as t
    on col.user_type_id = t.user_type_id
where col.is_nullable = 0 
and tab.name = @TableName
order by schema_name,
    table_name, 
    column_name;